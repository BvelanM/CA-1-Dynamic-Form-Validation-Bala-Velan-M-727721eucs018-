import logo from './logo.svg';
import './App.css';
import RegisterForm from './Pages/Login';
import './CSS/Style.css';

function App() {
  return (
    <>
    <RegisterForm />
    </>
  );
}

export default App;
